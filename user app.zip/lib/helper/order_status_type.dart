enum OrderStatusType {
  pending,
  accepted,
  processing,
  confirmed,
  handover,
  picked_up,
}